package edu.whu.demo.controller;

import edu.whu.demo.entity.GoodsItem;
import edu.whu.demo.service.GoodsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.UUID;
public class GoodsController {
    @Autowired
    GoodsService goodsService;

    @ApiOperation("根据ID查询商品编号")
    @GetMapping("/{id}")
    public ResponseEntity<GoodsItem> getGoods(@ApiParam("商品ID")@PathVariable long id){
        GoodsItem result=goodsService.getGoods(id);
        if(result==NULL){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(result);
        }
    }

    @ApiOperation("根据条件查询商品")
    @GetMapping("")
    public ResponseEntity<List<GoodsItem>> findGoods(@ApiParam("商品名称")String name,@ApiParam("是否有货")Boolean have){
        List<GoodsItem> result=goodsService.findGoods(name,complete);
        return ResponseEntity.ok(result);
    }

    @ApiOperation("添加商品")
    @PostMapping("")
    public ResponseEntity<GoodsItem> addTodo(@RequestBody GoodItem todo){
        GoodsItem result=goodsService.addGoods(goods);
        return ResponseEntity.ok(result);
    }

    @ApiOperation("修改商品")
    @PutMapping("/{id}")
    public ResponseEntity<void> updateGoods(@PathVariable long id,@ResquestBody GoodsItem goods){
        goodsService.updategoods(id,goods);
        return ResponseEntity.ok().build();
    }

    @ApiOperation("删除商品")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable long id){
        goodsService.deleteGoods(id);
        return ResponseEntity.ok().build();
    }
}
