package edu.whu.demo.service;

import edu.whu.demo.entity.GoodsItem;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class GoodsService {
    private Map<long,GoodsItem> goods=Collections.synchronizedMap(new HashMap<Long, GoodsItem>());

    public GoodsItem addGoods(GoodsItem goods){
        goods.put(goods.getId(),goods);
        return goods;
    }
    public GoodsItem getGoods(long id) {
        return goods.get(id);
    }

    public List<GoodsItem> findGoods(String name, Boolean have) {
        List<GoodsItem> result=new ArrayList<>();
        for (GoodsItem todo: goods.values()){
            if (name!=null && !goods.getName().contains(name)) {
                continue;
            }
            if (have!=null && !have.equals(goods.isinStock())) {
                continue;
            }
            result.add(goods);
        }
        return result;
    }

    public void updateGoods(long id, GoodsItem goods) {
        GoodsItem todo2  = goods.get(id);
        todo2.setName(goods.getName());
        todo2.setinStock(goods.isinStock());
        goods.put(id, goods2);
    }
    public void deleteGoods(long id) {
        goods.remove(id);
    }
}
